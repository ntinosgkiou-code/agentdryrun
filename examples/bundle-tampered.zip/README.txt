OmniOS evidence bundle
======================
Tenant: acme-demo     Log: omnios/acme-demo     Records: 67     Scope: all     Generated: 2026-10-23 09:16:00 UTC

HOW TO CHECK IT (Python 3.9 or newer, nothing to install):

    python verify.py bundle.zip --log-key <the log's public key, obtained from the customer by another route> \
                                --witness <name>=<that witness's public key>

* The log key in manifest.json is only a convenience. If you do not pin the key you obtained separately, the check is
  reported as UNPINNED and proves nothing about who runs the log.
* A witness is a program run by someone other than the operator. If a trusted witness cosigned this log, the operator
  could not have rewritten the part it saw without being caught. Without a witness the operator can rewrite history.
* verify.py inside this zip was produced by the same party as the zip. For a real check, use a copy of the verifier you obtained
  separately (and compare its sha256 with the one the vendor publishes).
* "VERIFIED" means: the records are exactly what was committed, they sit in the checkpointed tree, and the rules recorded
  in the ledger (distinct approvers, none of them the agent, enough approvals before execution) were followed.
  It does NOT mean the decisions were right, or that nothing was left out before being logged.
